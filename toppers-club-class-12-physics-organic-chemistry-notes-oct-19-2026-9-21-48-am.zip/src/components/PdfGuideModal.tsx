import React, { useState } from 'react';
import { X, FileText, Check, Copy, ExternalLink, FolderPlus, Cloud, UploadCloud } from 'lucide-react';

interface PdfGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectLocalPdf?: (file: File) => void;
}

export const PdfGuideModal: React.FC<PdfGuideModalProps> = ({ isOpen, onClose, onSelectLocalPdf }) => {
  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSnippet(id);
    setTimeout(() => setCopiedSnippet(null), 2000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onSelectLocalPdf) {
      onSelectLocalPdf(file);
      onClose();
    }
  };

  const codeSnippet = `// In src/data/chapters.ts:
export const PHYSICS_CHAPTERS: Chapter[] = [
  {
    id: 'phy-1',
    title: 'Electric Charges & Fields',
    // Add your PDF path in /public/notes/ or your Google Drive preview URL:
    pdfUrl: '/notes/physics-ch1-electric-charges.pdf', 
    // or: pdfUrl: 'https://drive.google.com/file/d/YOUR_FILE_ID/preview',
    ...
  }
];`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl max-h-[90vh] overflow-y-auto">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="space-y-2 mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-300 text-xs font-bold uppercase tracking-wider">
            <FileText className="w-3.5 h-3.5" />
            <span>Author &amp; Creator Guide</span>
          </div>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
            How to Add Your Own Class 12 Notes PDFs
          </h3>
          <p className="text-sm text-slate-300">
            You can showcase and distribute your actual handwritten notes PDFs using any of the 3 simple methods below:
          </p>
        </div>

        {/* Quick Instant Upload Banner */}
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <span className="text-xs font-bold text-amber-300 uppercase tracking-wide flex items-center gap-1">
              <UploadCloud className="w-4 h-4 text-amber-400" />
              <span>Instant Test in Browser Right Now</span>
            </span>
            <p className="text-xs text-slate-300 mt-0.5">
              Select a PDF from your phone/computer to view it instantly in the Preview section.
            </p>
          </div>
          <label className="shrink-0 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl cursor-pointer transition shadow-md">
            <span>Select PDF File</span>
            <input
              type="file"
              accept="application/pdf"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>
        </div>

        {/* 3 Step-by-Step Methods */}
        <div className="space-y-6 text-sm text-slate-300">
          
          {/* Method 1: Local /public/notes/ */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold text-xs flex items-center justify-center">
                1
              </div>
              <h4 className="font-bold text-white text-base">
                Method 1: Put your PDF files in the <code className="text-amber-300 bg-slate-900 px-1.5 py-0.5 rounded font-code">/public/notes/</code> directory
              </h4>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Any file placed in the <code className="text-slate-200">/public/notes/</code> folder is automatically accessible on the web.
            </p>
            <ol className="list-decimal list-inside text-xs text-slate-300 space-y-1.5 pl-1">
              <li>Save your PDF as e.g. <strong className="text-white">/public/notes/physics-ch1.pdf</strong>.</li>
              <li>Open <code className="text-amber-300 font-code">src/data/chapters.ts</code>.</li>
              <li>Add the line <code className="text-emerald-400 font-code">pdfUrl: '/notes/physics-ch1.pdf'</code> inside that chapter's object.</li>
              <li>The previewer will automatically load and display your real PDF file!</li>
            </ol>
            <div className="relative mt-2">
              <pre className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-[11px] font-code text-slate-300 overflow-x-auto">
                {codeSnippet}
              </pre>
              <button
                onClick={() => copyToClipboard(codeSnippet, 'snippet')}
                className="absolute top-2 right-2 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1 cursor-pointer"
              >
                {copiedSnippet === 'snippet' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSnippet === 'snippet' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Method 2: Google Drive Embed */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-400 font-bold text-xs flex items-center justify-center">
                2
              </div>
              <h4 className="font-bold text-white text-base">
                Method 2: Link Google Drive Public PDF Preview
              </h4>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              If your notes are already on Google Drive, you don't even need to store them locally:
            </p>
            <ol className="list-decimal list-inside text-xs text-slate-300 space-y-1.5 pl-1">
              <li>In Google Drive, right click your notes PDF &rarr; <strong>Share</strong> &rarr; Set to <strong>"Anyone with link can view"</strong>.</li>
              <li>Copy the link (e.g. <code className="text-slate-400 font-code">https://drive.google.com/file/d/1ABCXYZ.../view</code>).</li>
              <li>Change the ending <code className="text-rose-400 font-code">/view</code> to <code className="text-emerald-400 font-code">/preview</code>.</li>
              <li>Paste that link into the <strong>"Link Google Drive PDF"</strong> field in the preview section or in <code className="text-amber-300 font-code">src/data/chapters.ts</code>!</li>
            </ol>
          </div>

          {/* Method 3: Delivery on Payment */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-purple-500/20 text-purple-400 font-bold text-xs flex items-center justify-center">
                3
              </div>
              <h4 className="font-bold text-white text-base">
                How Paying Students Get the Full 220+ Pages Master PDF
              </h4>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              When a student pays through your UPI QR code and confirms their name, DOB and captcha:
            </p>
            <ul className="list-disc list-inside text-xs text-slate-300 space-y-1 pl-1">
              <li>The website automatically compiles and downloads the official PDF guidebook with their name and access pass.</li>
              <li>You can also link your Google Drive folder directly in <code className="text-amber-300 font-code">src/components/PaymentSection.tsx</code> so students can download the full multi-chapter drive folder directly!</li>
            </ul>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold cursor-pointer"
          >
            Got it, Let's View Notes!
          </button>
        </div>

      </div>
    </div>
  );
};
