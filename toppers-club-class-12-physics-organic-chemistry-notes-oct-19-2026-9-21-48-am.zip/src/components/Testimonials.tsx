import React from 'react';
import { STUDENT_REVIEWS } from '../data/chapters';
import { Star, ShieldCheck, TrendingUp, Award, Quote } from 'lucide-react';

export const Testimonials: React.FC = () => {
  return (
    <section id="reviews" className="py-20 bg-[#090d15] border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 text-xs font-bold text-amber-400 bg-amber-400/10 border border-amber-400/20 px-3 py-1 rounded-full uppercase tracking-wider mb-3">
            <Award className="w-3.5 h-3.5" />
            <span>Real Student Transformations</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            From Pre-Board Panic to 95%+ Board Marksheet
          </h2>
          <p className="mt-3 text-base text-slate-300">
            Read how Class 12 students across India used TOPPERS CLUB notes to master their derivations and organic reactions.
          </p>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
          {STUDENT_REVIEWS.map((review) => (
            <div
              key={review.id}
              className="p-6 sm:p-7 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-amber-500/30 transition-all duration-300 flex flex-col justify-between shadow-lg relative group"
            >
              <div>
                {/* Score transformation pill */}
                <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                  <div className="flex text-amber-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400" />
                    ))}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-full font-code">
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>{review.beforeScore} ➔ {review.afterScore}</span>
                  </div>
                </div>

                {/* Quote */}
                <p className="text-sm sm:text-base text-slate-300 leading-relaxed italic">
                  "{review.quote}"
                </p>
              </div>

              {/* Student Bio */}
              <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 font-bold flex items-center justify-center text-sm shadow-md">
                    {review.avatarLetter}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white leading-tight">
                      {review.name}
                    </h4>
                    <p className="text-xs text-slate-400">
                      {review.schoolOrCity}
                    </p>
                  </div>
                </div>

                <span className="text-[11px] font-semibold text-amber-400 bg-amber-400/10 px-2.5 py-1 rounded-md border border-amber-400/20">
                  {review.verifiedBadge}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Aggregate Stats */}
        <div className="mt-14 max-w-4xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
            <div className="text-2xl sm:text-3xl font-extrabold text-amber-400 font-code">8,420+</div>
            <div className="text-xs text-slate-400 mt-1">Students Downloaded</div>
          </div>
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
            <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-code">98.6%</div>
            <div className="text-xs text-slate-400 mt-1">Author's Board Score</div>
          </div>
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
            <div className="text-2xl sm:text-3xl font-extrabold text-cyan-400 font-code">28</div>
            <div className="text-xs text-slate-400 mt-1">5-Mark Derivations</div>
          </div>
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
            <div className="text-2xl sm:text-3xl font-extrabold text-white font-code">₹49</div>
            <div className="text-xs text-slate-400 mt-1">Affordable Slogan Price</div>
          </div>
        </div>

      </div>
    </section>
  );
};
